﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tagsTwo
{
    public partial class Form1 : Form
    {
        Game game;
        List<Button> cells = new List<Button>();
        Panel panel = new Panel();
        TableLayoutPanel tableLayoutPanel1;
        int size;

        private void CreateTable(int columns, int rows)
        {
            int tag = 0;
            panel.Controls.Clear();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.Dock = DockStyle.Fill;

            panel.Width = Convert.ToInt32(this.Width * 0.98f);
            panel.Height = Convert.ToInt32(this.Height * 0.95f);

            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            tableLayoutPanel1.Visible = true;
            tableLayoutPanel1.ColumnCount = columns;
            tableLayoutPanel1.RowCount = rows;

            int width = 100 / tableLayoutPanel1.ColumnCount;
            int height = 100 / tableLayoutPanel1.RowCount;

            for (int i = 0; i < tableLayoutPanel1.ColumnCount; i++)
            {
                tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, width));

                for (int j = 0; j < tableLayoutPanel1.RowCount; j++)
                {
                    tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, height));

                    var button = new Button();

                    button.Font = new Font("Bahnschrift", 50);
                    button.Text = "button" + tag.ToString();
                    button.Dock = DockStyle.Fill;
                    button.TextAlign = ContentAlignment.MiddleCenter;
                    button.Click += new System.EventHandler(this.Button_Click);
                    button.Tag = tag;
                    cells.Add(button);
                    tableLayoutPanel1.Controls.Add(button, j, i);
                    tag++;
                }
            }
            Controls.Add(panel);
            panel.Controls.Add(tableLayoutPanel1);
        }


        public Form1(int columns, int rows)
        {
            InitializeComponent();

            CreateTable(columns, rows);

            size = columns;

            game = new Game(size);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            start_game();
        }



        private void start_game()
        {
            game.start();
            for (int i = 0; i < 100; i++)
            {
                game.shift_random();
            }
            refresh();

        }
        private void refresh()
        {
            if (!game.check_win())
            {
                for (int position = 0; position < size * size; position++)
                {
                    int nr = game.get_number(position);
                    button(position).Text = nr.ToString();
                    button(position).Visible = (nr > 0);
                }
            }
            else
            {
                MessageBox.Show("You win! :D", "Congratilations!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
        }

        

        private void Button_Click(object sender, EventArgs e)
        {
            int position = Convert.ToInt32(((Button)sender).Tag);
            game.shift(position);
            refresh();
        }

        private Button button(int position)
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Button button = control as Button;
                if (button != null)
                {
                    if (position == Convert.ToInt32(button.Tag)) return button;
                }
            }
            return null;
        }
    }
}